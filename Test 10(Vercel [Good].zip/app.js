const supabaseUrl = 'https://mpcjnyuczjukfazplqjc.supabase.co';
const supabaseKey = 'sb_publishable_S8r-c688VW112n85RRZ7Vw_e5p7W6Fr';
const db = window.supabase.createClient(supabaseUrl, supabaseKey);

const stealthBtn = document.getElementById('stealth-btn');
const adminIndicator = document.getElementById('admin-indicator');

const projectBox = document.getElementById('project-container');
const projectFiltersBox = document.getElementById('project-filters');
const certBox = document.getElementById('cert-container');
const hobbyBox = document.getElementById('hobby-container');
const socialBox = document.getElementById('social-container');

const projectWrapper = document.getElementById('project-wrapper');
const certWrapper = document.getElementById('cert-wrapper');
const hobbyWrapper = document.getElementById('hobby-wrapper');
const socialWrapper = document.getElementById('social-wrapper');

const viewAllProjectsBtn = document.getElementById('view-all-projects-btn');
const viewAllCertBtn = document.getElementById('view-all-cert-btn');
const viewAllHobbyBtn = document.getElementById('view-all-hobby-btn');
const viewAllSocialBtn = document.getElementById('view-all-social-btn');

const addProjectBtn = document.getElementById('add-project-btn');
const addCertBtn = document.getElementById('add-cert-btn');
const addHobbyBtn = document.getElementById('add-hobby-btn');
const addSocialBtn = document.getElementById('add-social-btn');

// Profile elements
const profileTagline = document.getElementById('profile-tagline');
const profileBio = document.getElementById('profile-bio');
const profileTechStack = document.getElementById('profile-tech-stack');
const profileStatus = document.getElementById('profile-status');
const profileLocation = document.getElementById('profile-location');
const editProfileBtn = document.getElementById('edit-profile-btn');
const profileModal = document.getElementById('profile-modal');
const profileForm = document.getElementById('profile-form');

let isAdmin = false;
let profileData = null;
let currentHobbyId = null;
let allProjects = [];
let allCerts = [];
let activeFilters = new Set();

const systemOverlay = document.getElementById('system-overlay');
const systemBox = document.getElementById('system-box');
const notifYes = document.getElementById('notif-yes');
const notifNo = document.getElementById('notif-no');
const notifActions = document.getElementById('notif-actions');
const notifAuth = document.getElementById('notif-auth');
const notifTitle = document.getElementById('notif-title');
const notifPinInput = document.getElementById('notif-pin-input');
const notifSubmit = document.getElementById('notif-submit');
const notifMessage = document.getElementById('notif-message');

const lightboxModal = document.getElementById('lightbox-modal');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.getElementById('lightbox-close');
const lightboxPrev = document.getElementById('lightbox-prev');
const lightboxNext = document.getElementById('lightbox-next');
let currentLightboxImages = [];
let currentLightboxIndex = 0;

async function loadProfileInfo() {
  const { data } = await db.from('profile_info').select('*').eq('id', 1).single();
  if (data) {
    profileData = data;
    renderProfileInfo(data);
  }
}

function renderProfileInfo(data) {
  if (profileTagline) profileTagline.textContent = data.tagline || 'Unemployed Final Boss';
  if (profileBio) profileBio.textContent = data.bio || '';
  if (profileStatus) profileStatus.textContent = `Status: ${data.status || 'Training Arc'}`;
  if (profileLocation) profileLocation.textContent = data.location || 'Gingoog City, PH';
  
  if (profileTechStack && data.tech_stack) {
    profileTechStack.innerHTML = data.tech_stack.map(tech =>
      `<span class="px-3 py-1 bg-sky-100 rounded-lg text-xs tracking-widest uppercase shadow-sm border border-white font-bold text-sky-800">${tech}</span>`
    ).join('');
  }
}

async function loadPortfolio() {
  await loadProfileInfo();
  
  const { data: projects } = await db.from('projects').select('*');
  allProjects = projects || [];
  renderProjects(allProjects);
  
  const { data: certs } = await db.from('certificates').select('*');
  allCerts = certs || [];
  renderCertificates(allCerts);
  
  const { data: hobbies } = await db.from('hobbies').select('*').order('rank', { ascending: true });
  renderHobbies(hobbies || []);
  
  const { data: socials } = await db.from('socials').select('*');
  renderSocials(socials || []);
}

async function toggleVisibility(tableName, categoryValue, currentStatus, colName) {
  const { error } = await db.from(tableName).update({ is_visible: !currentStatus }).eq(colName, categoryValue);
  if (error) alert("Error: " + error.message);
  else loadPortfolio();
}

function renderProjects(projects) {
  if (!projectBox) return;
  if (!projects || projects.length === 0) {
    projectBox.innerHTML = "<p class='text-sky-700/60 font-bold ml-4 col-span-full'>No projects found.</p>";
    projectFiltersBox.innerHTML = "<p class='text-sm text-sky-700/60 font-medium italic'>No filters active...</p>";
    return;
  }
  
  let allLangs = new Set();
  projects.forEach(p => {
    if (p.languages) p.languages.split(',').forEach(l => allLangs.add(l.trim()));
  });
  
  projectFiltersBox.innerHTML = Array.from(allLangs).sort().map(lang => `
        <label class="flex items-center gap-2 bg-white/60 hover:bg-white px-5 py-2 rounded-full border border-white/50 shadow-sm cursor-pointer transition-all duration-300 hover:shadow-md ${activeFilters.has(lang) ? 'bg-sky-100 border-sky-300' : ''}">
            <input type="checkbox" value="${lang}" class="hidden" ${activeFilters.has(lang) ? 'checked' : ''} onchange="toggleFilter('${lang}')">
            <span class="text-xs font-bold text-sky-900 uppercase tracking-widest">${lang}</span>
        </label>
    `).join('');
  
  const filteredProjects = activeFilters.size === 0 ?
    projects :
    projects.filter(p => {
      if (!p.languages) return false;
      const pLangs = p.languages.split(',').map(l => l.trim());
      return Array.from(activeFilters).some(f => pLangs.includes(f));
    });
  
  if (filteredProjects.length === 0) {
    projectBox.innerHTML = "<p class='text-sky-700/60 font-bold ml-4 col-span-full'>No projects match the selected stack.</p>";
    return;
  }
  
  projectBox.innerHTML = filteredProjects.map(p => {
    const langsHtml = p.languages ?
      p.languages.split(',').map(l => `<span class="bg-white/80 text-sky-900 text-[10px] px-3 py-1.5 rounded-md font-bold border border-white shadow-sm tracking-widest uppercase">${l.trim()}</span>`).join('') :
      '';
    return `
            <div class="glass-card p-6 md:p-8 flex flex-col group relative overflow-hidden bg-white/40">
                <div class="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/70 to-transparent pointer-events-none"></div>
                <div class="relative mb-6 rounded-2xl overflow-hidden shadow-md border border-white">
                    <img src="${p.image_url}" class="h-56 w-full object-cover transition-transform duration-700 group-hover:scale-105">
                    <div class="absolute inset-0 bg-gradient-to-t from-sky-900/40 to-transparent pointer-events-none"></div>
                    ${isAdmin ? `<button onclick="deleteItem('projects', '${p.id}')" class="absolute top-3 right-3 bg-red-500/90 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm shadow-lg border border-red-400 font-bold z-20 hover:bg-red-600 transition-colors backdrop-blur-sm">&#x2715;</button>` : ''}
                </div>
                <h3 class="text-2xl font-extrabold text-sky-950 mb-4 relative z-10 tracking-tight aero-title">${p.title}</h3>
                <div class="flex flex-wrap gap-2 mb-4 relative z-10">${langsHtml}</div>
                <p class="text-sm text-slate-600 font-medium mb-8 flex-1 relative z-10 leading-relaxed">${p.description || ''}</p>
                ${p.link ? `<a href="${p.link}" target="_blank" class="glossy-btn text-center text-xs py-3.5 font-bold relative z-10 tracking-[0.2em] uppercase">View Project</a>` : ''}
            </div>
        `;
  }).join('');
}

window.toggleFilter = function(lang) {
  if (activeFilters.has(lang)) activeFilters.delete(lang);
  else activeFilters.add(lang);
  renderProjects(allProjects);
}

const certSearchInput = document.getElementById('cert-search');
if (certSearchInput) {
  certSearchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase().trim();
    if (term === '') renderCertificates(allCerts);
    else {
      const filtered = allCerts.filter(c => c.category_name?.toLowerCase().includes(term) || c.title?.toLowerCase().includes(term));
      renderCertificates(filtered);
    }
  });
}

function renderCertificates(certs) {
  if (!certBox) return;
  if (!certs || certs.length === 0) return certBox.innerHTML = "<p class='text-sky-700/60 font-bold ml-4'>No certifications found.</p>";
  
  const groups = {};
  certs.forEach(c => {
    if (!groups[c.category_name]) groups[c.category_name] = [];
    groups[c.category_name].push(c);
  });
  
  certBox.innerHTML = '';
  for (const category in groups) {
    const desc = groups[category][0].description || "Description pending.";
    const isVisible = groups[category][0].is_visible !== false;
    
    if (!isVisible && !isAdmin) continue;
    
    certBox.innerHTML += `
            <div class="glass-card p-8 transition-all relative overflow-hidden bg-white/50 ${!isVisible ? 'opacity-50 grayscale' : ''}">
                <div class="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/60 to-transparent pointer-events-none"></div>
                <div class="flex flex-wrap items-center gap-4 mb-3 relative z-10">
                    <h3 class="text-2xl font-extrabold text-sky-950">${category}</h3>
                    ${isAdmin ? `
                        <button onclick="editContainerDesc('${category}', 'certificates', 'category_name')" class="text-[10px] bg-white hover:bg-slate-50 border border-slate-200 shadow-sm px-3 py-1.5 rounded-md text-slate-700 font-bold uppercase tracking-widest transition-colors">Edit</button>
                        <button onclick="toggleVisibility('certificates', '${category}', ${isVisible}, 'category_name')" class="text-[10px] ${isVisible ? 'bg-sky-100 text-sky-800' : 'bg-red-100 text-red-800'} border border-white shadow-sm px-3 py-1.5 rounded-md font-bold uppercase tracking-widest">
                            ${isVisible ? 'Public' : 'Hidden'}
                        </button>
                    ` : ''}
                </div>
                <p class="text-slate-600 text-sm mb-8 font-medium relative z-10 max-w-3xl">${desc}</p>
                <div class="flex flex-wrap gap-6 relative z-10">
                    ${groups[category].map(cert => `
                        <div class="relative group cursor-pointer">
                            <img src="${cert.image_url}" onclick="openLightbox('${cert.image_url}')" class="cert-img-target h-40 w-56 object-cover rounded-xl border-2 border-white shadow-lg shadow-sky-900/10 cursor-zoom-in transition-all duration-300 group-hover:scale-105 group-hover:shadow-xl">
                            <div class="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent rounded-xl pointer-events-none"></div>
                            ${isAdmin ? `<button onclick="deleteItem('certificates', '${cert.id}')" class="absolute -top-3 -right-3 bg-red-500/90 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm shadow-lg border border-red-400 font-bold hover:bg-red-600 transition-colors backdrop-blur-sm z-20">&#x2715;</button>` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
  }
}

function renderHobbies(hobbies) {
  if (!hobbyBox) return;
  if (!hobbies || hobbies.length === 0) return hobbyBox.innerHTML = "<p class='text-emerald-700/60 font-bold ml-4'>No interests found.</p>";
  
  const groups = {};
  hobbies.forEach(h => {
    if (!groups[h.category]) groups[h.category] = [];
    groups[h.category].push(h);
  });
  
  hobbyBox.innerHTML = '';
  for (const category in groups) {
    const desc = groups[category][0].description || "Description pending.";
    const isVisible = groups[category][0].is_visible !== false;
    
    if (!isVisible && !isAdmin) continue;
    
    hobbyBox.innerHTML += `
            <div class="glass-card p-8 transition-all relative overflow-hidden bg-white/50 ${!isVisible ? 'opacity-50 grayscale' : ''}">
                <div class="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/60 to-transparent pointer-events-none"></div>
                <div class="flex flex-wrap items-center gap-4 mb-3 relative z-10">
                    <h3 class="text-2xl font-extrabold text-emerald-950">${category}</h3>
                    ${isAdmin ? `
                        <button onclick="editContainerDesc('${category}', 'hobbies', 'category')" class="text-[10px] bg-white hover:bg-slate-50 border border-slate-200 shadow-sm px-3 py-1.5 rounded-md text-slate-700 font-bold uppercase tracking-widest transition-colors">Edit</button>
                        <button onclick="toggleVisibility('hobbies', '${category}', ${isVisible}, 'category')" class="text-[10px] ${isVisible ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'} border border-white shadow-sm px-3 py-1.5 rounded-md font-bold uppercase tracking-widest">
                            ${isVisible ? 'Public' : 'Hidden'}
                        </button>
                    ` : ''}
                </div>
                <p class="text-slate-600 text-sm mb-8 font-medium relative z-10 max-w-3xl">${desc}</p>
                <div class="flex flex-wrap gap-6 relative z-10">
                    ${groups[category].map(h => `
                        <div class="relative flex flex-col bg-white/80 p-4 rounded-2xl border border-white shadow-lg shadow-emerald-900/5 hover:-translate-y-2 transition-all duration-300 w-52 group">
                            <div class="relative overflow-hidden rounded-xl border border-white shadow-sm">
                                <img src="${h.cover_image}" class="h-40 w-full object-cover transition-transform duration-500 group-hover:scale-110">
                                <div class="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent pointer-events-none"></div>
                                <span class="absolute top-2 left-2 bg-white/95 text-emerald-800 text-[10px] px-3 py-1 rounded-md font-black shadow-sm backdrop-blur-md border border-white uppercase tracking-widest">RANK #${h.rank}</span>
                                ${isAdmin ? `<button onclick="deleteItem('hobbies', '${h.id}')" class="absolute top-2 right-2 bg-red-500/90 text-white rounded-full w-7 h-7 flex items-center justify-center text-xs shadow-md border border-red-400 font-bold z-10 hover:bg-red-600 backdrop-blur-sm">&#x2715;</button>` : ''}
                            </div>
                            <div class="flex flex-col mt-5 gap-3">
                                <h4 class="font-extrabold text-[15px] text-slate-800 truncate tracking-tight text-center" title="${h.title}">${h.title}</h4>
                                <div class="flex gap-2">
                                    ${h.show_info !== false ? `<button onclick="openInfo('${h.tags || ''}')" class="flex-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-[10px] py-2 rounded-lg font-bold tracking-widest uppercase shadow-sm transition-all hover:shadow">INFO</button>` : ''}
                                    ${h.show_view !== false ? `<button onclick="openGallery('${h.id}', '${h.title}', '${h.cover_image}')" class="flex-1 glossy-btn-green text-[10px] py-2 font-bold tracking-widest uppercase">VIEW</button>` : ''}
                                </div>
                            </div>
                            ${isAdmin ? `
                                <button onclick="editTags('${h.id}', '${h.tags || ''}')" class="mt-4 w-full text-[10px] bg-slate-100 hover:bg-slate-200 py-2 rounded-lg text-slate-700 font-bold border border-slate-200 shadow-sm transition-colors uppercase tracking-widest">
                                    Update Tags
                                </button>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
  }
}

function renderSocials(socials) {
  if (!socialBox) return;
  if (!socials || socials.length === 0) return socialBox.innerHTML = "<p class='text-sky-700/60 font-bold ml-4'>No links found.</p>";
  
  socialBox.innerHTML = socials.map(s => `
        <div class="relative w-full sm:w-[340px] group">
            <a href="${s.link}" target="_blank" class="flex items-center gap-5 glass-card p-5 rounded-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden bg-white/70">
                <div class="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/90 to-transparent pointer-events-none"></div>
                <div class="relative w-14 h-14 rounded-xl overflow-hidden shadow-md border border-white flex-shrink-0 bg-white">
                    <img src="${s.image_url}" class="w-full h-full object-cover">
                </div>
                <div class="flex flex-col overflow-hidden relative z-10">
                    <span class="font-extrabold text-slate-800 truncate text-lg tracking-tight">${s.platform}</span>
                    <span class="text-xs text-sky-600 font-bold truncate tracking-wider uppercase opacity-80">${s.link.replace(/^https?:\/\//, '')}</span>
                </div>
            </a>
            ${isAdmin ? `<button onclick="deleteItem('socials', '${s.id}')" class="absolute -top-3 -right-3 bg-red-500/90 text-white rounded-full w-8 h-8 flex items-center justify-center text-xs shadow-lg border border-red-400 font-bold z-20 hover:bg-red-600 backdrop-blur-sm">&#x2715;</button>` : ''}
        </div>
    `).join('');
}

function toggleViewAll(btn, wrapper, defaultLabel) {
  if (!wrapper || !btn) return;
  wrapper.classList.toggle('section-expanded');
  btn.innerText = wrapper.classList.contains('section-expanded') ? 'Collapse' : defaultLabel;
}

if (viewAllProjectsBtn) viewAllProjectsBtn.addEventListener('click', () => toggleViewAll(viewAllProjectsBtn, projectWrapper, 'View All Projects'));
if (viewAllCertBtn) viewAllCertBtn.addEventListener('click', () => toggleViewAll(viewAllCertBtn, certWrapper, 'View All Certifications'));
if (viewAllHobbyBtn) viewAllHobbyBtn.addEventListener('click', () => toggleViewAll(viewAllHobbyBtn, hobbyWrapper, 'View All Interests'));
if (viewAllSocialBtn) viewAllSocialBtn.addEventListener('click', () => toggleViewAll(viewAllSocialBtn, socialWrapper, 'View All'));

window.openLightbox = function(clickedUrl) {
  const images = Array.from(document.querySelectorAll('.cert-img-target'));
  currentLightboxImages = images.map(img => img.src);
  currentLightboxIndex = currentLightboxImages.indexOf(clickedUrl);
  if (currentLightboxIndex === -1) currentLightboxIndex = 0;
  updateLightboxImage();
  lightboxModal.classList.remove('hidden');
}

function updateLightboxImage() {
  if (currentLightboxImages.length > 0) lightboxImg.src = currentLightboxImages[currentLightboxIndex];
}

if (lightboxClose) lightboxClose.addEventListener('click', () => lightboxModal.classList.add('hidden'));
if (lightboxPrev) lightboxPrev.addEventListener('click', () => {
  currentLightboxIndex = (currentLightboxIndex - 1 + currentLightboxImages.length) % currentLightboxImages.length;
  updateLightboxImage();
});
if (lightboxNext) lightboxNext.addEventListener('click', () => {
  currentLightboxIndex = (currentLightboxIndex + 1) % currentLightboxImages.length;
  updateLightboxImage();
});

window.openInfo = function(tags) {
  const container = document.getElementById('info-tags-container');
  if (!tags || tags === 'null' || tags.trim() === '') {
    container.innerHTML = '<p class="text-slate-500 font-medium italic text-sm">No tags added yet.</p>';
  } else {
    const tagArray = tags.split(',').map(t => t.trim()).filter(t => t);
    container.innerHTML = tagArray.map(t => `<span class="bg-sky-50 text-sky-800 px-4 py-2 rounded-lg text-[10px] font-black border border-sky-100 shadow-sm tracking-widest uppercase">${t}</span>`).join('');
  }
  document.getElementById('info-modal').classList.remove('hidden');
}

window.closeInfo = function() { document.getElementById('info-modal').classList.add('hidden'); }

window.editTags = async function(hobbyId, currentTags) {
  const safeTags = currentTags === 'null' ? '' : currentTags;
  const newTags = prompt("Update tags (comma separated):", safeTags);
  if (newTags !== null) {
    const { error } = await db.from('hobbies').update({ tags: newTags }).eq('id', hobbyId);
    if (error) alert("Error: " + error.message);
    else loadPortfolio();
  }
}

window.editContainerDesc = async function(categoryValue, tableName, columnName) {
  const newDesc = prompt(`Update description for ${categoryValue}:`);
  if (newDesc !== null) {
    const { error } = await db.from(tableName).update({ description: newDesc }).eq(columnName, categoryValue);
    if (error) alert("Error: " + error.message);
    else loadPortfolio();
  }
}

stealthBtn.addEventListener('click', () => {
  resetSystemNotif();
  showSystemNotif();
});

function showSystemNotif() {
  systemOverlay.classList.remove('hidden');
  setTimeout(() => {
    systemBox.classList.remove('scale-90', 'opacity-0');
    systemBox.classList.add('scale-100', 'opacity-100');
  }, 10);
}

function resetSystemNotif() {
  systemBox.className = "relative w-[90%] max-w-md p-[2px] transition-all duration-500 ease-out scale-90 opacity-0 bg-gradient-to-br from-cyan-400 to-blue-600 shadow-[0_0_30px_rgba(0,180,255,0.5)] rounded-xl";
  notifTitle.innerText = "SYSTEM NOTIFICATION";
  notifTitle.className = "text-cyan-400 font-black tracking-[0.2em] text-2xl mb-2 italic";
  notifMessage.innerHTML = "Identity verification required.<br><span class='text-sm opacity-70'>Are you the System Administrator?</span>";
  notifActions.classList.remove('hidden');
  notifAuth.classList.add('hidden');
  notifPinInput.value = "";
}

function initSystemNotif() {
  const isDismissed = localStorage.getItem('systemNotifDismissed');
  if (!isDismissed) showSystemNotif();
}

notifNo.addEventListener('click', () => {
  localStorage.setItem('systemNotifDismissed', 'true');
  closeSystemNotif();
});

notifYes.addEventListener('click', () => {
  // Solo Leveling violet style
  systemBox.className = "relative w-[90%] max-w-md p-[2px] transition-all duration-500 ease-out scale-100 opacity-100 bg-gradient-to-br from-violet-500 via-purple-600 to-violet-900 shadow-[0_0_40px_rgba(139,92,246,0.7),0_0_80px_rgba(139,92,246,0.4)] rounded-xl animate-pulse-glow";
  notifTitle.innerText = "ADMINISTRATOR ACCESS";
  notifTitle.className = "text-violet-400 font-black tracking-[0.2em] text-2xl mb-2 italic";
  notifMessage.innerHTML = "Authorization required.<br><span class='text-sm opacity-70'>Please provide your access code.</span>";
  notifActions.classList.add('hidden');
  notifAuth.classList.remove('hidden');
  // Update auth input and button to violet theme
  notifPinInput.className = "w-full bg-black border-b-2 border-violet-500 text-center text-2xl text-violet-400 font-black outline-none py-2 placeholder:text-violet-900/50";
  notifSubmit.className = "w-full py-3 border border-violet-500/50 bg-violet-900/20 text-violet-400 font-black hover:bg-violet-500 hover:text-white transition-all duration-300 tracking-widest uppercase rounded-lg";
  notifPinInput.focus();
});

notifSubmit.addEventListener('click', () => {
  if (notifPinInput.value === "2026") {
    isAdmin = true;
    adminIndicator.classList.remove('hidden');
    [addProjectBtn, addCertBtn, addHobbyBtn, addSocialBtn, editProfileBtn].forEach(btn => btn?.classList.remove('hidden'));
    loadPortfolio();
    closeSystemNotif();
  } else {
    notifPinInput.value = "";
    notifPinInput.placeholder = "ACCESS DENIED";
    notifPinInput.classList.add('animate-pulse', 'border-red-500', 'text-red-500');
    setTimeout(() => notifPinInput.classList.remove('animate-pulse', 'border-red-500', 'text-red-500'), 500);
  }
});

function closeSystemNotif() {
  systemBox.classList.remove('scale-100', 'opacity-100');
  systemBox.classList.add('scale-110', 'opacity-0');
  setTimeout(() => {
    systemOverlay.classList.add('hidden');
    systemBox.classList.remove('scale-110');
  }, 500);
}

const adminModal = document.getElementById('admin-modal');
const adminForm = document.getElementById('admin-form');

function openModal(type) {
  document.getElementById('form-type').value = type;
  document.getElementById('modal-title').innerText = `Add ${type.charAt(0).toUpperCase() + type.slice(1)}`;
  const catContainer = document.getElementById('category-field');
  const catLabel = document.getElementById('category-label');
  const inputCat = document.getElementById('input-category');
  const titleLabel = document.getElementById('title-label');
  const descField = document.getElementById('description-field');
  const urlField = document.getElementById('url-field');
  const hobbyFields = document.getElementById('hobby-only-fields');
  const socialFields = document.getElementById('social-only-fields');
  
  catContainer.classList.remove('hidden');
  inputCat.setAttribute('required', 'true');
  descField.classList.add('hidden');
  urlField.classList.add('hidden');
  hobbyFields.classList.add('hidden');
  socialFields.classList.add('hidden');
  
  if (type === 'project') {
    catLabel.innerText = "Languages (Comma Separated)";
    titleLabel.innerText = "Project Title";
    descField.classList.remove('hidden');
    urlField.classList.remove('hidden');
  } else if (type === 'social') {
    catContainer.classList.add('hidden');
    inputCat.removeAttribute('required');
    socialFields.classList.remove('hidden');
    titleLabel.innerText = "Platform Name";
  } else if (type === 'hobby') {
    catLabel.innerText = "Category";
    titleLabel.innerText = "Title";
    hobbyFields.classList.remove('hidden');
  } else if (type === 'cert') {
    catLabel.innerText = "Category";
    titleLabel.innerText = "Title";
  }
  adminModal.classList.remove('hidden');
  adminModal.classList.add('flex');
}

window.closeModal = function() {
  adminModal.classList.add('hidden');
  adminModal.classList.remove('flex');
  adminForm.reset();
}

if (addProjectBtn) addProjectBtn.addEventListener('click', () => openModal('project'));
if (addCertBtn) addCertBtn.addEventListener('click', () => openModal('cert'));
if (addHobbyBtn) addHobbyBtn.addEventListener('click', () => openModal('hobby'));
if (addSocialBtn) addSocialBtn.addEventListener('click', () => openModal('social'));

adminForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const type = document.getElementById('form-type').value;
  const category = document.getElementById('input-category').value;
  const title = document.getElementById('input-title').value;
  const description = document.getElementById('input-description')?.value;
  const url = document.getElementById('input-url')?.value;
  const rank = document.getElementById('input-rank')?.value;
  const socialLink = document.getElementById('input-social-link')?.value;
  const showInfo = document.getElementById('input-show-info')?.checked;
  const showView = document.getElementById('input-show-view')?.checked;
  const file = document.getElementById('input-file').files[0];
  
  if (!file) return alert("Please select an image.");
  const fileName = `${type}s/${Date.now()}-${file.name}`;
  await db.storage.from('portfolio-assets').upload(fileName, file);
  const { data: urlData } = db.storage.from('portfolio-assets').getPublicUrl(fileName);
  const publicUrl = urlData.publicUrl;
  
  let dbError;
  if (type === 'project') {
    const { error } = await db.from('projects').insert([{ languages: category, title, description, link: url, image_url: publicUrl }]);
    dbError = error;
  } else if (type === 'cert') {
    const { error } = await db.from('certificates').insert([{ category_name: category, title, image_url: publicUrl }]);
    dbError = error;
  } else if (type === 'hobby') {
    const { error } = await db.from('hobbies').insert([{ category, title, cover_image: publicUrl, rank: parseInt(rank) || 0, show_info: showInfo, show_view: showView }]);
    dbError = error;
  } else if (type === 'social') {
    const { error } = await db.from('socials').insert([{ platform: title, link: socialLink, image_url: publicUrl }]);
    dbError = error;
  }
  
  if (dbError) alert("Database Error: " + dbError.message);
  else { closeModal();
    loadPortfolio(); }
});

window.deleteItem = async function(table, id) {
  if (confirm('Remove this item?')) {
    await db.from(table).delete().eq('id', id);
    loadPortfolio();
  }
}

window.openGallery = async function(hobbyId, title, coverImgUrl) {
  currentHobbyId = hobbyId;
  document.getElementById('gallery-title').innerText = title;
  const imgContainer = document.getElementById('gallery-images');
  const addBtn = document.getElementById('gallery-add-btn');
  
  if (addBtn) isAdmin ? addBtn.classList.remove('hidden') : addBtn.classList.add('hidden');
  
  imgContainer.innerHTML = `<div class="relative group cursor-pointer hover:scale-105 transition-transform duration-300"><img src="${coverImgUrl}" class="max-h-96 w-auto rounded-2xl shadow-[0_0_30px_rgba(255,255,255,0.1)] border border-white/20"></div>`;
  
  document.getElementById('gallery-modal').classList.remove('hidden');
  document.getElementById('gallery-modal').classList.add('flex');
  
  const { data: extraImages } = await db.from('hobby_gallery').select('image_url').eq('hobby_id', hobbyId);
  if (extraImages) extraImages.forEach(img => {
    imgContainer.innerHTML += `<div class="relative group cursor-pointer hover:scale-105 transition-transform duration-300"><img src="${img.image_url}" class="max-h-96 w-auto rounded-2xl shadow-[0_0_30px_rgba(255,255,255,0.1)] border border-white/20"></div>`;
  });
}

const galleryInput = document.getElementById('gallery-upload-input');
const galleryAddBtn = document.getElementById('gallery-add-btn');

if (galleryAddBtn) galleryAddBtn.onclick = () => galleryInput.click();
if (galleryInput) {
  galleryInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file || !currentHobbyId) return;
    const fileName = `gallery/${Date.now()}-${file.name}`;
    await db.storage.from('portfolio-assets').upload(fileName, file);
    const { data: urlData } = db.storage.from('portfolio-assets').getPublicUrl(fileName);
    await db.from('hobby_gallery').insert([{ hobby_id: currentHobbyId, image_url: urlData.publicUrl }]);
    loadPortfolio();
    closeGallery();
  };
}

window.closeGallery = function() {
  document.getElementById('gallery-modal').classList.add('hidden');
  document.getElementById('gallery-modal').classList.remove('flex');
  currentHobbyId = null;
}

// Profile Edit Functions
if (editProfileBtn) {
  editProfileBtn.addEventListener('click', () => {
    if (profileData) {
      document.getElementById('input-profile-tagline').value = profileData.tagline || '';
      document.getElementById('input-profile-bio').value = profileData.bio || '';
      document.getElementById('input-profile-tech').value = (profileData.tech_stack || []).join(', ');
      document.getElementById('input-profile-status').value = profileData.status || '';
      document.getElementById('input-profile-location').value = profileData.location || '';
    }
    profileModal.classList.remove('hidden');
    profileModal.classList.add('flex');
  });
}

window.closeProfileModal = function() {
  profileModal.classList.add('hidden');
  profileModal.classList.remove('flex');
}

if (profileForm) {
  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const tagline = document.getElementById('input-profile-tagline').value;
    const bio = document.getElementById('input-profile-bio').value;
    const techStackStr = document.getElementById('input-profile-tech').value;
    const status = document.getElementById('input-profile-status').value;
    const location = document.getElementById('input-profile-location').value;
    
    const techStack = techStackStr.split(',').map(t => t.trim()).filter(t => t);
    
    const { error } = await db.from('profile_info').update({
      tagline,
      bio,
      tech_stack: techStack,
      status,
      location,
      updated_at: new Date().toISOString()
    }).eq('id', 1);
    
    if (error) {
      alert("Error: " + error.message);
    } else {
      closeProfileModal();
      loadPortfolio();
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initSystemNotif();
  loadPortfolio();
});