function register() {
  
  let username = document.getElementById("regUser").value;
  let password = document.getElementById("regPass").value;
  
  if (username === "" || password === "") {
    alert("Fill all fields");
    return;
  }
  
  let users = JSON.parse(localStorage.getItem("users")) || [];
  
  let exist = users.find(u => u.username === username);
  
  if (exist) {
    alert("Username already exists");
    return;
  }
  
  users.push({
    username,
    password
  });
  
  localStorage.setItem("users", JSON.stringify(users));
  
  alert("Account Created!");
}

function login() {
  
  let username = document.getElementById("logUser").value;
  let password = document.getElementById("logPass").value;
  
  let users = JSON.parse(localStorage.getItem("users")) || [];
  
  let user = users.find(
    u => u.username === username && u.password === password
  );
  
  if (!user) {
    alert("Invalid Login");
    return;
  }
  
  localStorage.setItem("loggedIn", username);
  
  document.getElementById("auth").style.display = "none";
  document.getElementById("app").style.display = "block";
  
  loadStudents();
}

function logout() {
  
  localStorage.removeItem("loggedIn");
  
  document.getElementById("auth").style.display = "block";
  document.getElementById("app").style.display = "none";
}

function addStudent() {
  
  let name = document.getElementById("studentName").value;
  let id = document.getElementById("studentId").value;
  let gpa = document.getElementById("studentGpa").value;
  
  if (name === "" || id === "" || gpa === "") {
    alert("Complete all fields");
    return;
  }
  
  let students = JSON.parse(localStorage.getItem("students")) || [];
  
  students.push({
    name,
    id,
    gpa
  });
  
  localStorage.setItem("students", JSON.stringify(students));
  
  loadStudents();
  
  alert("Student Added!");
  
  document.getElementById("studentName").value = "";
  document.getElementById("studentId").value = "";
  document.getElementById("studentGpa").value = "";
}

function deleteStudent(index) {
  
  let students = JSON.parse(localStorage.getItem("students")) || [];
  
  students.splice(index, 1);
  
  localStorage.setItem("students", JSON.stringify(students));
  
  loadStudents();
}

function loadStudents() {
  
  let students = JSON.parse(localStorage.getItem("students")) || [];
  
  let table = document.getElementById("studentTable");
  
  table.innerHTML = "";
  
  students.forEach((student, index) => {
    
    table.innerHTML += `
      <tr>
        <td>${student.name}</td>
        <td>${student.id}</td>
        <td>${student.gpa}</td>
        <td>
          <button class="delete-btn"
          onclick="deleteStudent(${index})">
          Delete
          </button>
        </td>
      </tr>
    `;
  });
}

if (localStorage.getItem("loggedIn")) {
  
  document.getElementById("auth").style.display = "none";
  document.getElementById("app").style.display = "block";
  
  loadStudents();
}